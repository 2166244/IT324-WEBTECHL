A Pen created at CodePen.io. You can find this one at https://codepen.io/Exophonics/pen/zGqmza.

 3 Cheers for no JavaScript!!

Note: For a number of reasons, this method might not be entirely suitable, featuring a number of limitations including the Arrow hitbox. I have tried to make it as customisable as possible using a Pure CSS produced triangle for the Arrow Indicator. I also understand that the dropdown cannot be initiated by clicking on the text, I'm going to try to find a CSS-based solution to this problem as soon as possible ;)