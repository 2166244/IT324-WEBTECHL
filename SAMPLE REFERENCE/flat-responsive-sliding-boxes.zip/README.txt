A Pen created at CodePen.io. You can find this one at https://codepen.io/rexkirby/pen/yjxso.

 Flat Responsive Sliding Boxes using HTML5 and CSS3.

Taken from a project I did called The Kite Map. View that here: http://thekitemap.com/