A Pen created at CodePen.io. You can find this one at https://codepen.io/imprakash/pen/GgNMXO.

 check out the full explanation at http://www.sevensignature.com/blog/code/pure-css-popup-without-javascript